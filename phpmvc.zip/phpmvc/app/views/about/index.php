<div class="container">
    
    <h1 class="mt-4">About Me</h1>
     <img src="<?= BASEURL; ?>/img/risa.jpg" alt="risa" width="200" class="rounded-circle shadow">
    <p>Halo, nama saya <?= $data['nama']; ?>, umur saya <?= $data['umur']; ?> tahun, saya adalah seorang <?= $data['pekerjaan']; ?>.</p>

</div>
 