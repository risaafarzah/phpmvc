<?php 

class User_model {
    private $nama = ' Risa Farzah';

    public function getUser()
    {
        return $this->nama;
    }
}